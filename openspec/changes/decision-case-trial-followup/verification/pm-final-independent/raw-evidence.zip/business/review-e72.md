# Issue #154 非作者业务切片复核（e72 原始结论）

复核者：`/root/trial_runtime_audit/final_business_matrix`，未参与候选产品实现。审查根 `/workspace/OptraCall-issue154-second-review`。实际只读 HEAD `e72df020f1040e68c3b16f12df1df6177dfc4a16`；相对 main `74030911ade7a9e06ad1a0213d1fcb93ecbba6dd` 审查 CF03–CF07 的全部实际源差异。PM后续修改与本记录分别核定；这是原始发现，不被修后PASS覆盖。

结论：**2 项 P2 需要 PM 接修**。正常业务权限/对象权威未发现新增破坏；本切片不是完整UI或运行时终验结论。

## 本轮实际读取与执行

已读 AGENTS、工程规范四原则/官方SDK/IN01–07/冻结逐项复核与PR前截图门禁、followup spec/tasks、原daily-workspace spec DW01–18与§4、冻结demo的对应DOM/CSS/事件源码。已按实际diff审 `CaseIssuePanel`、`CasePreparation`、`CaseBoard`、`App`、`ProjectNavigation`、`ProjectBoard`、`strategy-discussion`、`project-session`、`strategy-discussion-host`；不只接受原 `second-review.md` 的PASS。

亲自运行：Node25.9.0，`node --test --test-name-pattern='CF0[3-7]:' tests/case-trial-followup-fixes.test.ts`，5/5 PASS，见 `target-tests.log`。测试均为已有组件hook harness/Store合成输入，未开启Host/browser/Provider。TMPDIR在本复核目录中；本轮新探针只写本目录。未修改候选/测试/规范/旧证据/SDK，未Git写入、Issue、PR或Mac操作。两项新增问题使用实际产品组件bundle+原hook harness，受控输入与卸载/网络完成时序，边界见下。

此切片没有亲自渲染冻结Demo或查看产品截图，不作视觉一致性PASS；父独立复核者承担实图与最终Host/SDK/Chromium收据的增量核验。

## 发现 B1（P2）：CF03 空态导航在原事项卸载后仍触发旧owner回调

位置：`src/host/ui/CaseIssuePanel.tsx:391`（去准备 Plan Task）、`:404`（去关联或新建项目）；`:394–398` 的展开交接入口同样缺少卸载后的中止检查，但展开只影响旧引用，主要风险是前两项外部导航。

新增handler在 `await choiceDraft.flush()` 之后直接 `task('plan')` / `onLinkProject()`，未检查已有的 `mounted.current`。实际组件bundle复现步骤：

1. 在空方案事项中输入理由；
2. 点“去准备 Plan Task”，让原草稿 PUT 挂起；
3. 卸载当前组件（代表owner切换/父级离开）；
4. 释放原PUT成功回执。

实际 `onCreate` 仍被调用1次，带旧 `caseId:case-1 / issueId:issue-1` 的Plan intent。探针未模拟真实浏览器自然串案，也未发任何业务创建POST；它直接证明旧owner异步导航回调在卸载后仍存活。与 CF03“取消/往返不串事项”、DW13/DW16的迟到结果边界不符。已有 `submitChoice` 在保存后核 `mounted.current` 可作同域参照。建议PM在异步草稿确认后、外部导航/DOM帧回调前核mounted/当前owner，保留原草稿确认结果，不重放保存。

证据：`late-plan-navigation-probe.mjs`、`late-plan-navigation-probe.json`；原 `steps` 保留PUT挂起→卸载→旧回调顺序。`Link` handler结构同源，本轮未另跑其回调；不能把结构推断写成第二个已跑用例。

## 发现 B2（P2）：CF06 列表在首事项完成前刷新一次，完成后卡片仍缓存0事项

位置：`src/host/ui/CasePreparation.tsx:313–315`，`App.tsx` 的onCaseChanged→refreshSeq，`CaseBoard.tsx:163–181`及`DailyCaseCard.tsx:20–47`。

created分支在 `finishFirstIssue` 之前调用onCaseChanged，首事项成功后只setNotice，没有再次使列表/首页失效；`DailyCaseCard`按 `record.id/revision` 重读目录，旧list记录rev1不会因独立事项POST结束而自动变化。

实际组件级因果复现：

1. Case创建成功，首事项尚不存在；
2. onCaseChanged触发一次，已挂载CaseBoard/DailyCaseCard读到新Case及0事项；
3. 首事项POST挂起后成功释放，准备页明确显示“与第一件事项已建立”；
4. 没有第二次通知（refreshes仍1），总览卡片仍显示“0件事项／当前还没有事项／浏览不会自动创建事项”。

证据：`first-issue-refresh-probe.mjs`、`first-issue-refresh-probe.json`，完整事件顺序、完成后准备页文本与陈旧卡片文本均保留。父复核者另已查看PM最终第三Case真实截图为0事项，但该Host的准确API事项计数由根PM另核；本报告不把截图推成未经读取的API事实。

建议：保持created早期通知来展示部分成功，并在准确首事项/片段确认成功后再次onCaseChanged；completed原操作续办分支已是先finish后通知。回归应人为延迟首事项写回，确保最终return无需手动刷新，卡片不仅出现唯一Case，也显示准确首事项与本轮入口。

## CF03–CF07 / 冻结规范 / 任务矩阵

| 条目 | 代码核对与实际测试 | 结论/边界 |
| --- | --- | --- |
| CF03 / T04 / DW02、05、13 | 空方案select明确禁用并说明G/S不是准确方案；已有项目走准确Case/issue Plan intent，无项目透传原Link/Create入口；新按钮先flush草稿；未修改Plan来源接回、取舍/CAS、行动授权、反馈保存权威。已有CF03组件回归PASS。 | 正常引导符合；B1迟到导航FAIL。完整Plan→交回→取舍→授权→反馈→原看板历史由父复核者核PM最新E2E，本切片未亲跑。 |
| CF04 / T05 / DW08–09、§4.3 | 两类target schema与Store解析字段一致；新建省略requestId，修订保留原CAS；Host仍由真实owner绑定issueId、从当前SDK request/session/tool派生operation/source；权限/授权/反馈基线/来源检查未移除。诊断只派生固定字段路径，不返回原输入值；原source/native权威不变。CF04合成Store负例和字段定位回归PASS。 | 静态与本轮单位覆盖PASS；合法choose/observe实际Host保存及首页派生需核父复核者E2E/旧消费者证据；不是本切片亲跑。 |
| CF05 / T06 / DW11、13–14 | 本地必要字段校验移至写业务前，错误设置准确输入ref/展开位置；只在确定CaseRequestError<500且没有createAttempt时清goalAttempt；部分/未知沿原冻结operation和回执，不重建采纳。草稿按钮按dirty显示“保存当前草稿”。CF05空个人名/Goal400回归PASS。 | 变更范围内PASS；旧UNKNOWN/跨Store原子性不扩称。本轮未逐个亲跑所有老恢复用例。 |
| CF06 / T07 / DW10–14、16 | App通知CaseBoard的refreshSeq，列表失败保留旧数据并显示旧快照，筛选/范围状态未重置；continue/partial分支不新增Case业务POST；已有CF06组件测试PASS但只模拟外部列表刷新。 | B2首事项完成后的二次失效缺失FAIL；原测试不覆盖该时序，不能据其PASS关闭。 |
| CF07 / T08 / DW06–07、17 | 侧栏archive/restore/rename及项目详情动作AX名加project.name；原闭包ID、归档准入/写保护、Esc与焦点代码未改；未改共享>1规则。CF07 AX名称组件回归PASS。 | 本轮静态与AX单位覆盖PASS；同名项目必须按项目行上下文定位，名称字符串不代替唯一ID。实际单项目操作范围由父复核者核E2E。 |

## 四原则与范围

- Host仅增强错误/输入环境、可访问名称及失效重读；本切片没有Host代造方案/复制G/S、自动授权/反馈、解除connected门禁等越权路径。
- Agent工具由原Pi schema与原Host窄适配调用，未加固定分析步骤/循环，仍允许Agent根据明确工具错误自主纠正。
- 未改SDK/依赖/锁文件，没有新Runtime/业务台账；沿原CaseStore/Board/operation/CAS/draft/source权威。本切片没有重新验官方包归档完整性，不将“无SDK diff”扩大成供应链审计。
- 局部引导/字段定位/自动列表刷新减少用户重复操作，没有新日常确认步骤；B1/B2属于新增异步UI环境管理未完整收尾，需要PM修正。
- 截图用户确认仍为开PR前门禁；本切片无权据代码或单位PASS解除。Mac/真实GLM与原现场自然根因仍未核。
