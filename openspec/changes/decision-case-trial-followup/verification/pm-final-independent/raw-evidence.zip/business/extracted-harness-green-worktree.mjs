import test from 'node:test';
import assert from 'node:assert/strict';
import { build } from 'esbuild';
import { runInNewContext } from 'node:vm';
import { observeTask,                           } from 'file:///workspace/OptraCall-issue154-second-review/src/host/ui/runtime-client.ts';
import { watchStrategyDiscussion, StrategyDiscussionRequestError } from 'file:///workspace/OptraCall-issue154-second-review/src/host/ui/strategy-discussion-client.ts';
import { caseDeclarationsTool, explainCaseDeclarationError } from 'file:///workspace/OptraCall-issue154-second-review/src/agent/strategy-discussion.ts';
import { CaseStore } from 'file:///workspace/OptraCall-issue154-second-review/src/host/case-store.ts';
import { createCaseIssueService } from 'file:///workspace/OptraCall-issue154-second-review/src/host/case-issues.ts';
import { emptyPreparePayload } from 'file:///workspace/OptraCall-issue154-second-review/src/host/ui/case-preparation-model.ts';
import { diagnoseCaseDecisionRequestError } from 'file:///workspace/OptraCall-issue154-second-review/src/host/strategy-discussion-host.ts';
import { createDecisionBoardStore } from 'file:///workspace/OptraCall-issue154-second-review/extensions/business-plugins/decision-board/storage/store.ts';
                                                                                                                     
import { randomUUID } from 'node:crypto';
import { mkdtempSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';

                                                                                    
const descendants = (node     )            => !node || typeof node !== 'object' ? [] : Array.isArray(node) ? node.flatMap(descendants) : [node, ...descendants(node.props?.children)];
const textOf = (node     )         => node == null || node === false ? '' : typeof node === 'string' || typeof node === 'number' ? String(node) : Array.isArray(node) ? node.map(textOf).join('') : textOf(node.props?.children);

let roleBundle                    ;
async function mountBusinessRole(fetcher              , initialOwner                         ) {
  roleBundle ??= (await build({
    entryPoints: ['src/host/ui/BusinessRoleConversation.tsx'],
    bundle: true, write: false, platform: 'browser', format: 'iife', loader: { '.css': 'empty' }, globalName: 'RoleUiTest',
    plugins: [{
      name: 'role-test-hooks',
      setup(plugin) {
        plugin.onResolve({ filter: /^react(?:\/jsx-runtime)?$/ }, args => ({ path: args.path, namespace: 'role-hooks' }));
        plugin.onLoad({ filter: /.*/, namespace: 'role-hooks' }, args => ({
          contents: args.path.endsWith('jsx-runtime')
            ? 'export const jsx=(type,props)=>({type,props});export const jsxs=jsx;export const Fragment="fragment";'
            : 'export const useState=v=>globalThis.__roleHooks.state(v);export const useRef=v=>globalThis.__roleHooks.ref(v);export const useEffect=(f,d)=>globalThis.__roleHooks.effect(f,d);export const useLayoutEffect=(f,d)=>globalThis.__roleHooks.effect(f,d);export const useCallback=(f,d)=>globalThis.__roleHooks.memo(()=>f,d);export const useMemo=(f,d)=>globalThis.__roleHooks.memo(f,d);export const useId=()=>globalThis.__roleHooks.id();export const Fragment="fragment";export const memo=c=>c;',
        }));
      },
    }],
  })).outputFiles[0].text;
  const instances = new Map                                                                                                   ();
  const effects                 = [];
  let activeInst = { values: []         , deps: []           , cleanups: []                  , memos: []                           };
  let cursor = 0;
  let currentOwner = initialOwner;
  const hooks = {
    state(initial     ) { const inst = activeInst, i = cursor++; if (!(i in inst.values)) inst.values[i] = typeof initial === 'function' ? initial() : initial; return [inst.values[i], (v     ) => { inst.values[i] = typeof v === 'function' ? v(inst.values[i]) : v; }]; },
    ref(initial     ) { const inst = activeInst, i = cursor++; return inst.values[i] ??= { current: initial }; },
    memo(fn           , next       ) { const inst = activeInst, i = cursor++; if (!inst.memos[i] || !next || next.some((v, n) => v !== inst.memos[i].d[n])) inst.memos[i] = { v: fn(), d: next ?? [] }; return inst.memos[i].v; },
    id() { return `role-${cursor++}`; },
    effect(fn           , next       ) { const inst = activeInst, i = cursor++; if (!inst.deps[i] || next.some((v, n) => v !== inst.deps[i][n])) { inst.deps[i] = next; effects.push(() => { inst.cleanups[i]?.(); inst.cleanups[i] = fn(); }); } },
  };
  const sStore = new Map                (), lStore = new Map                ();
  const storageApi = (m                     ) => ({ getItem: (k        ) => m.get(k) ?? null, setItem: (k        , v        ) => m.set(k, v), removeItem: (k        ) => m.delete(k) });
  const sandbox                      = {
    __roleHooks: hooks, fetch: fetcher, structuredClone, crypto,
    Response, Request, Headers, URL, URLSearchParams, TextDecoder, TextEncoder, setTimeout, clearTimeout,
    AbortController, AbortSignal, DOMException, ReadableStream,
    sessionStorage: storageApi(sStore), localStorage: storageApi(lStore),
    window: { addEventListener() {}, removeEventListener() {} },
  };
  runInNewContext(roleBundle, sandbox);
  const { BusinessRoleConversation } = sandbox.RoleUiTest;
  const seenKeys = new Set        ();
  const expand = (node     , path = 'root')      => {
    if (!node || typeof node !== 'object') return node;
    if (Array.isArray(node)) return node.map((child, idx) => expand(child, `${path}.${idx}`));
    if (typeof node.type === 'function') {
      const instKey = `${path}:${node.type.name || 'fn'}:${node.props?.key ?? ''}`;
      seenKeys.add(instKey);
      let inst = instances.get(instKey);
      if (!inst) { inst = { values: [], deps: [], cleanups: [], memos: [] }; instances.set(instKey, inst); }
      const prevInst = activeInst, prevCursor = cursor;
      activeInst = inst; cursor = 0;
      const rendered = node.type(node.props);
      activeInst = prevInst; cursor = prevCursor;
      return expand(rendered, instKey);
    }
    if (node.props?.children !== undefined) return { ...node, props: { ...node.props, children: expand(node.props.children, path) } };
    return node;
  };
  let tree         ;
  const render = () => {
    seenKeys.clear();
    tree = expand({ type: BusinessRoleConversation, props: { owner: currentOwner } });
    for (const [k, inst] of [...instances.entries()]) {
      if (!seenKeys.has(k)) { for (const fn of inst.cleanups) fn?.(); instances.delete(k); }
    }
    while (effects.length) effects.shift() ();
    return tree;
  };
  const settle = async (rounds = 8) => { for (let i = 0; i < rounds; i++) { await new Promise(r => setImmediate(r)); render(); } };
  render(); await settle();
  return {
    setOwner(next                         ) { currentOwner = next; render(); },
    render, settle,
    nodes: () => descendants(tree),
    text: () => textOf(tree),
    close() { for (const inst of instances.values()) for (const fn of inst.cleanups) fn?.(); },
  };
}

let issuePanelBundle                    ;
async function mountCaseIssuePanel(fetcher              , extraProps                          = {}) {
  issuePanelBundle ??= (await build({
    entryPoints: ['src/host/ui/CaseIssuePanel.tsx'],
    bundle: true, write: false, platform: 'browser', format: 'iife', loader: { '.css': 'empty' }, globalName: 'IssuePanelUiTest',
    plugins: [{
      name: 'issue-panel-test-hooks',
      setup(plugin) {
        plugin.onResolve({ filter: /^react(?:\/jsx-runtime)?$/ }, args => ({ path: args.path, namespace: 'issue-hooks' }));
        plugin.onLoad({ filter: /.*/, namespace: 'issue-hooks' }, args => ({
          contents: args.path.endsWith('jsx-runtime')
            ? 'export const jsx=(type,props)=>({type,props});export const jsxs=jsx;export const Fragment="fragment";'
            : 'export const useState=v=>globalThis.__issueHooks.state(v);export const useRef=v=>globalThis.__issueHooks.ref(v);export const useEffect=(f,d)=>globalThis.__issueHooks.effect(f,d);export const useCallback=(f,d)=>globalThis.__issueHooks.memo(()=>f,d);export const useMemo=(f,d)=>globalThis.__issueHooks.memo(f,d);export const useId=()=>globalThis.__issueHooks.id();',
        }));
        plugin.onResolve({ filter: /BusinessRoleConversation\.tsx$/ }, () => ({ path: 'role-conv', namespace: 'issue-stubs' }));
        plugin.onResolve({ filter: /CaseFeedbackDialog\.tsx$/ }, () => ({ path: 'fb-dlg', namespace: 'issue-stubs' }));
        plugin.onLoad({ filter: /.*/, namespace: 'issue-stubs' }, args => ({
          contents: args.path === 'role-conv' ? 'export function BusinessRoleConversation(){return null;}' : 'export function CaseFeedbackDialog(){return null;}',
        }));
      },
    }],
  })).outputFiles[0].text;
  const instances = new Map                                                                                                   ();
  const effects                 = [];
  let activeInst = { values: []         , deps: []           , cleanups: []                  , memos: []                           };
  let cursor = 0;
  const hooks = {
    state(initial     ) { const inst = activeInst, i = cursor++; if (!(i in inst.values)) inst.values[i] = typeof initial === 'function' ? initial() : initial; return [inst.values[i], (v     ) => { inst.values[i] = typeof v === 'function' ? v(inst.values[i]) : v; }]; },
    ref(initial     ) { const inst = activeInst, i = cursor++; return inst.values[i] ??= { current: initial }; },
    memo(fn           , next       ) { const inst = activeInst, i = cursor++; if (!inst.memos[i] || !next || next.some((v, n) => v !== inst.memos[i].d[n])) inst.memos[i] = { v: fn(), d: next ?? [] }; return inst.memos[i].v; },
    id() { return `issue-ui-${cursor++}`; },
    effect(fn           , next       ) { const inst = activeInst, i = cursor++; if (!inst.deps[i] || next.some((v, n) => v !== inst.deps[i][n])) { inst.deps[i] = next; effects.push(() => { inst.cleanups[i]?.(); inst.cleanups[i] = fn(); }); } },
  };
  const sStore = new Map                (), lStore = new Map                ();
  const storageApi = (m                     ) => ({ getItem: (k        ) => m.get(k) ?? null, setItem: (k        , v        ) => m.set(k, v), removeItem: (k        ) => m.delete(k) });
  const sandbox                      = {
    __issueHooks: hooks, fetch: fetcher, structuredClone, crypto,
    Response, Request, Headers, URL, URLSearchParams, setTimeout, clearTimeout,
    AbortController, AbortSignal, DOMException, HTMLElement: class HTMLElement {},
    sessionStorage: storageApi(sStore), localStorage: storageApi(lStore),
    window: { addEventListener() {}, removeEventListener() {} },
    document: { activeElement: null, getElementById: () => null },
    requestAnimationFrame: (cb            ) => { cb(); return 1; },
  };
  runInNewContext(issuePanelBundle, sandbox);
  const { CaseIssuePanel } = sandbox.IssuePanelUiTest;
  const props      = {
    record: { id: 'case-1', title: '测试 Case', status: 'analyzing', revision: 1, description: '', judgement: '', nextStep: '', updatedAt: '2026-11-28T00:00:00Z', createdAt: '2026-11-28T00:00:00Z' },
    projects: [],
    onChange() {},
    onCreate() {},
    ...extraProps,
  };
  const expand = (node     , path = 'root')      => {
    if (!node || typeof node !== 'object') return node;
    if (Array.isArray(node)) return node.map((child, idx) => expand(child, `${path}.${idx}`));
    if (typeof node.type === 'function') {
      const instKey = `${path}:${node.type.name || 'fn'}:${node.props?.key ?? ''}`;
      let inst = instances.get(instKey);
      if (!inst) { inst = { values: [], deps: [], cleanups: [], memos: [] }; instances.set(instKey, inst); }
      const prevInst = activeInst, prevCursor = cursor;
      activeInst = inst; cursor = 0;
      const rendered = node.type(node.props);
      activeInst = prevInst; cursor = prevCursor;
      return expand(rendered, instKey);
    }
    if (node.props?.children !== undefined) return { ...node, props: { ...node.props, children: expand(node.props.children, path) } };
    return node;
  };
  let tree         ;
  const render = () => { tree = expand({ type: CaseIssuePanel, props }); while (effects.length) effects.shift() (); return tree; };
  const settle = async (rounds = 12) => { for (let i = 0; i < rounds; i++) { await new Promise(r => setImmediate(r)); render(); } };
  render(); await settle();
  return { props, render, settle, nodes: () => descendants(tree), text: () => textOf(tree), close() { for (const inst of instances.values()) for (const fn of inst.cleanups) fn?.(); } };
}

let prepBundle                    ;
async function mountCasePrep(fetcher              , initialProps                          = {}) {
  prepBundle ??= (await build({
    entryPoints: ['src/host/ui/CasePreparation.tsx'],
    bundle: true, write: false, platform: 'browser', format: 'iife', globalName: 'PrepFollowupTest',
    plugins: [{
      name: 'prep-followup-hooks',
      setup(plugin) {
        plugin.onResolve({ filter: /^react(?:\/jsx-runtime)?$/ }, args => ({ path: args.path, namespace: 'prep-hooks' }));
        plugin.onLoad({ filter: /.*/, namespace: 'prep-hooks' }, args => ({
          contents: args.path.endsWith('jsx-runtime')
            ? 'export const jsx=(type,props)=>({type,props});export const jsxs=jsx;export const Fragment="fragment";'
            : 'export const useState=v=>globalThis.__prepHooks.state(v);export const useRef=v=>globalThis.__prepHooks.ref(v);export const useEffect=(f,d)=>globalThis.__prepHooks.effect(f,d);export const useId=()=>globalThis.__prepHooks.id();',
        }));
        plugin.onResolve({ filter: /BusinessRoleConversation\.tsx$/ }, () => ({ path: 'role-conv', namespace: 'prep-stubs' }));
        plugin.onLoad({ filter: /role-conv/, namespace: 'prep-stubs' }, () => ({ contents: 'export function BusinessRoleConversation(){return null;}' }));
      },
    }],
  })).outputFiles[0].text;
  const values        = [], deps          = [], cleanups                 = [], effects                 = [];
  let cursor = 0;
  const hooks = {
    state(initial     ) { const i = cursor++; if (!(i in values)) values[i] = typeof initial === 'function' ? initial() : initial; return [values[i], (v     ) => { values[i] = typeof v === 'function' ? v(values[i]) : v; }]; },
    ref(initial     ) { const i = cursor++; return values[i] ??= { current: initial }; },
    id() { return `prep-${cursor++}`; },
    effect(fn           , next       ) { const i = cursor++; if (!deps[i] || next.some((v, n) => v !== deps[i][n])) { deps[i] = next; effects.push(() => { cleanups[i]?.(); cleanups[i] = fn(); }); } },
  };
  const sandbox                      = {
    __prepHooks: hooks, fetch: fetcher, structuredClone, crypto,
    Response, Request, Headers, URL, URLSearchParams, setTimeout, clearTimeout,
    window: { addEventListener() {}, removeEventListener() {} },
  };
  runInNewContext(prepBundle, sandbox);
  const { CasePreparation } = sandbox.PrepFollowupTest;
  let tree         ;
  const props      = { onOpenCase() {}, ...initialProps };
  const render = () => { cursor = 0; tree = CasePreparation(props); while (effects.length) effects.shift() (); return tree; };
  const settle = async (rounds = 10) => { for (let i = 0; i < rounds; i++) { await new Promise(r => setImmediate(r)); render(); } };
  render(); await settle();
  return { props, render, settle, nodes: () => descendants(tree), text: () => textOf(tree), close() { for (const fn of cleanups) fn?.(); } };
}

let boardBundle                    ;
async function mountCaseBoard(fetcher              , extraProps                          = {}) {
  boardBundle ??= (await build({
    entryPoints: ['src/host/ui/CaseBoard.tsx'],
    bundle: true, write: false, platform: 'browser', format: 'iife', loader: { '.css': 'empty' }, globalName: 'BoardFollowupTest',
    plugins: [{
      name: 'board-followup-hooks',
      setup(plugin) {
        plugin.onResolve({ filter: /^react(?:\/jsx-runtime)?$/ }, args => ({ path: args.path, namespace: 'board-hooks' }));
        plugin.onLoad({ filter: /.*/, namespace: 'board-hooks' }, args => ({
          contents: args.path.endsWith('jsx-runtime')
            ? 'export const jsx=(type,props)=>({type,props});export const jsxs=jsx;export const Fragment="fragment";'
            : 'export const useState=v=>globalThis.__boardHooks.state(v);export const useRef=v=>globalThis.__boardHooks.ref(v);export const useEffect=(f,d)=>globalThis.__boardHooks.effect(f,d);export const useLayoutEffect=(f,d)=>globalThis.__boardHooks.effect(f,d);export const useCallback=(f,d)=>globalThis.__boardHooks.memo(()=>f,d);export const useMemo=(f,d)=>globalThis.__boardHooks.memo(f,d);export const useId=()=>globalThis.__boardHooks.id();export const Fragment="fragment";export const memo=c=>c;',
        }));
        for (const stub of [/BusinessRoleConversation\.tsx$/, /CaseFeedbackDialog\.tsx$/, /CaseIssuePanel\.tsx$/, /CaseEnterpriseMaterials\.tsx$/, /CaseRelationsPanel\.tsx$/, /CaseGoalsPanel\.tsx$/, /CaseDecisionsPanel\.tsx$/]) {
          plugin.onResolve({ filter: stub }, args => ({ path: args.path, namespace: 'board-stubs' }));
        }
        plugin.onLoad({ filter: /.*/, namespace: 'board-stubs' }, () => ({
          contents: 'export function BusinessRoleConversation(){return null;} export function CaseFeedbackDialog(){return null;} export function CaseIssuePanel(){return null;} export function CaseEnterpriseMaterials(){return null;} export function CaseRelationsPanel(){return null;} export function createCaseRelationDraft(){return {};} export const initialCaseRelationUi={selected:null,editorOpen:false,draft:null}; export function caseRelationName(r){return r?.relationId??"";} export function CaseGoalsPanel(){return null;} export function CaseDecisionsPanel(){return null;} export const emptyCaseDecisionUiState = {};',
        }));
      },
    }],
  })).outputFiles[0].text;
  const instances = new Map                                                                                                   ();
  const effects                 = [];
  let activeInst = { values: []         , deps: []           , cleanups: []                  , memos: []                           };
  let cursor = 0;
  const hooks = {
    state(initial     ) { const inst = activeInst, i = cursor++; if (!(i in inst.values)) inst.values[i] = typeof initial === 'function' ? initial() : initial; return [inst.values[i], (v     ) => { inst.values[i] = typeof v === 'function' ? v(inst.values[i]) : v; }]; },
    ref(initial     ) { const inst = activeInst, i = cursor++; return inst.values[i] ??= { current: initial }; },
    memo(fn           , next       ) { const inst = activeInst, i = cursor++; if (!inst.memos[i] || !next || next.some((v, n) => v !== inst.memos[i].d[n])) inst.memos[i] = { v: fn(), d: next ?? [] }; return inst.memos[i].v; },
    id() { return `board-${cursor++}`; },
    effect(fn           , next       ) { const inst = activeInst, i = cursor++; if (!inst.deps[i] || next.some((v, n) => v !== inst.deps[i][n])) { inst.deps[i] = next; effects.push(() => { inst.cleanups[i]?.(); inst.cleanups[i] = fn(); }); } },
  };
  const sStore = new Map                (), lStore = new Map                ();
  const storageApi = (m                     ) => ({ getItem: (k        ) => m.get(k) ?? null, setItem: (k        , v        ) => m.set(k, v), removeItem: (k        ) => m.delete(k) });
  const sandbox                      = {
    __boardHooks: hooks, fetch: fetcher, structuredClone, crypto,
    Response, Request, Headers, URL, URLSearchParams, setTimeout, clearTimeout,
    AbortController, AbortSignal, DOMException, HTMLElement: class HTMLElement {},
    sessionStorage: storageApi(sStore), localStorage: storageApi(lStore),
    window: { addEventListener() {}, removeEventListener() {}, location: { href: 'http://localhost/' } },
    document: { activeElement: null, getElementById: () => null },
    requestAnimationFrame: (cb            ) => { cb(); return 1; },
    cancelAnimationFrame() {},
  };
  runInNewContext(boardBundle, sandbox);
  const { CaseBoard } = sandbox.BoardFollowupTest;
  const props      = {
    visible: true,
    decisionUi: {},
    onDecisionUiChange() {},
    projects: [],
    configurations: [],
    onOpenTask() {},
    onCreateTask() {},
    onProjectChange: async () => {},
    ...extraProps,
  };
  const expand = (node     , path = 'root')      => {
    if (!node || typeof node !== 'object') return node;
    if (Array.isArray(node)) return node.map((child, idx) => expand(child, `${path}.${idx}`));
    if (typeof node.type === 'function') {
      const instKey = `${path}:${node.type.name || 'fn'}:${node.props?.key ?? ''}`;
      let inst = instances.get(instKey);
      if (!inst) { inst = { values: [], deps: [], cleanups: [], memos: [] }; instances.set(instKey, inst); }
      const prevInst = activeInst, prevCursor = cursor;
      activeInst = inst; cursor = 0;
      const rendered = node.type(node.props);
      activeInst = prevInst; cursor = prevCursor;
      return expand(rendered, instKey);
    }
    if (node.props?.children !== undefined) return { ...node, props: { ...node.props, children: expand(node.props.children, path) } };
    return node;
  };
  let tree         ;
  const render = () => { tree = expand({ type: CaseBoard, props }); while (effects.length) effects.shift() (); return tree; };
  const settle = async (rounds = 10) => { for (let i = 0; i < rounds; i++) { await new Promise(r => setImmediate(r)); render(); } };
  render(); await settle();
  return { props, render, settle, nodes: () => descendants(tree), text: () => textOf(tree), close() { for (const inst of instances.values()) for (const fn of inst.cleanups) fn?.(); } };
}

let navBundle                    ;
async function mountProjectNav(projects                 ) {
  navBundle ??= (await build({
    entryPoints: ['src/host/ui/ProjectNavigation.tsx'],
    bundle: true, write: false, platform: 'browser', format: 'iife', globalName: 'NavFollowupTest',
    plugins: [{
      name: 'nav-followup-hooks',
      setup(plugin) {
        plugin.onResolve({ filter: /^react(?:\/jsx-runtime)?$/ }, args => ({ path: args.path, namespace: 'nav-hooks' }));
        plugin.onLoad({ filter: /.*/, namespace: 'nav-hooks' }, args => ({
          contents: args.path.endsWith('jsx-runtime')
            ? 'export const jsx=(type,props)=>({type,props});export const jsxs=jsx;export const Fragment="fragment";'
            : 'export const useState=v=>globalThis.__navHooks.state(v);export const useEffect=()=>{};',
        }));
      },
    }],
  })).outputFiles[0].text;
  const values        = [];
  let cursor = 0;
  const sandbox                      = {
    __navHooks: { state(initial     ) { const i = cursor++; if (!(i in values)) values[i] = typeof initial === 'function' ? initial() : initial; return [values[i], (v     ) => { values[i] = typeof v === 'function' ? v(values[i]) : v; }]; } },
  };
  runInNewContext(navBundle, sandbox);
  const { ProjectNavigation } = sandbox.NavFollowupTest;
  const tree = ProjectNavigation({
    projects, states: {}, loading: false,
    onProject() {}, onTask() {}, onCreateTask() {}, onRename() {}, onArchive() {}, onRestore() {},
  });
  return descendants(tree);
}

export {mountCaseIssuePanel,mountCasePrep,mountCaseBoard,emptyPreparePayload,textOf,descendants};
