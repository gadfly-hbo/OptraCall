# Issue #154 业务切片增量复核（green-worktree）

对原 `review-e72.md` 的 B1/B2，由根PM修改候选；本复核者只读，未参与实现。两项原RED JSON/脚本及e72原报告保持，不追溯改写为PASS。

亲自回跑原两探针的副本，触发与断言观察逻辑不变，仅输出JSON/日志与生成辅助harness目标加 `green-worktree`。全部使用实际产品组件bundle+原hook harness，Node25.9.0，无Host/Provider/浏览器。

- **B1 PASS（受控卸载迟到回执）**：原PUT挂起→卸载→释放成功回执顺序不变，`callbackCount: 0`。见 `late-plan-navigation-probe-green-worktree.json`、`late-plan-navigation-green-worktree.log`。新增三个await后均核`mounted.current`，交接RAF也再次核，原正常导航语义不变。
- **B2 PASS（首事项完成后二次失效）**：首轮仍可显示Case已创建/0事项；释放首事项POST后新增第二次onCaseChanged（`refreshes:2`），真实CaseBoard/DailyCaseCard重读list/目录，变为“1件事项／当前事项First issue input／继续当前事项”。见 `first-issue-refresh-probe-green-worktree.json`、`first-issue-refresh-green-worktree.log`。原部分成功早期通知与完成后通知分别保留。

实际被测业务文件哈希（回跑前后相同）：

| 文件 | SHA256 |
| --- | --- |
| `src/host/ui/CaseIssuePanel.tsx` | `2f1e7112776e47b8e04d6f342cb9bd589ff49815b6d2a05e3e279325c3a95ef6` |
| `src/host/ui/CasePreparation.tsx` | `e1a0f79d13d112267229d2e2ecd17647f354df065cfea16d19fa0e46dc1f5c1f` |

方法备注：第一次副本回跑按原脚本会再生成同名辅助`extracted-harness.mjs`；及时将green辅助文件改为独立目标，并从已固定e72测试源码恢复原RED辅助harness（相同原导出集合），原RED脚本与JSON未重跑或覆盖。后续两green副本分别运行成功，原RED JSON在本次尾部另哈希保留。该辅助文件处理不属于产品RED，也没有改候选源。

范围：B1/B2的组件条件复核已关闭；其他CF03–07结论沿原e72静态/单位审查，根PM最终SHA固定后须再核哈希；真实最终Host/SDK/E2E/截图与开PR前用户确认由父独立复核者统一核验，本增量不单独证明完整UI交付通过。

最终固定绑定：`b88af4aa6dfd7f998bfb3e5e119b87820b287d99`，工作树clean。两被测业务文件哈希与上述GREEN回跑一致，未漂移，未无故重跑。`final-b88-binding.json`列出9个业务文件与原RED/新GREEN产物哈希；其余7个业务文件与原e72切片逐字节相同。B1/B2在本切片覆盖范围关闭，原失败保留。
