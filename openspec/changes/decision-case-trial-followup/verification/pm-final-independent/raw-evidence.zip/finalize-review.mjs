import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
const root=process.cwd(), out=path.join(root,'.local/independent-final-review');
const input=JSON.parse(await fs.readFile(path.join(out,'input-a643bf00.json'),'utf8'));
const b88=JSON.parse(await fs.readFile(path.join(out,'input-b88af4aa.json'),'utf8'));
const own=JSON.parse(await fs.readFile(path.join(out,'final-browser/receipt.json'),'utf8'));
const pm=JSON.parse(await fs.readFile(path.join(root,'.local/pm-review/final-product/e2e-receipt.json'),'utf8'));
const hash=buf=>createHash('sha256').update(buf).digest('hex');
const current=[];for(const f of input.files){const data=await fs.readFile(path.join(root,f.path));current.push({...f,currentSha256:hash(data),matchesCandidate:hash(data)===f.sha256});}
if(current.some(f=>!f.matchesCandidate&&f.path!=='openspec/changes/decision-case-trial-followup/tasks.md'))throw Error('Reviewed product/spec input drift');
const taskDocIncrement=execFileSync('git',['diff','--','openspec/changes/decision-case-trial-followup/tasks.md'],{encoding:'utf8'});
await fs.writeFile(path.join(out,'tasks-evidence-increment.diff'),taskDocIncrement);
const head=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim();
if(head!==input.head || own.runtime.runtime.commit!==head || pm.runtime.commit!==head)throw Error('Runtime/source mismatch');
const imageRows=[];
for(const [set,dir] of [['frozen','frozen'],['independent-production','final-browser']])for(const name of (await fs.readdir(path.join(out,dir))).filter(f=>f.endsWith('.png')).sort()){const file=path.join(out,dir,name);imageRows.push({set,path:path.relative(root,file),sha256:hash(await fs.readFile(file)),personallyViewed:true});}
for(const name of (await fs.readdir(path.join(root,'.local/pm-review/final-product'))).filter(f=>f.endsWith('.png')).sort()){const file=path.join(root,'.local/pm-review/final-product',name);imageRows.push({set:'pm-production',path:path.relative(root,file),sha256:hash(await fs.readFile(file)),personallyViewed:true,executedBy:'PM'});}
let report=await fs.readFile(path.join(out,'final-review.md'),'utf8');
report=report.replace('**结论暂待最终生产产品浏览器只读查看与图证绑定补齐**；以下源码、测试与修正收口已完成，不能据此提前PR。','**最终结论：在本报告明确的工程复核范围内 PASS，未遗留已确认阻塞。** 真实生产dist同源浏览与最终16图已完成独立核验；三项原RED均经原样GREEN及永久回归关闭。T10用户看图确认、PR/head CI、授权合并与main CI仍待执行，不能据此提前PR。');
report=report.replace('原74截图/native未上传','原始截图/native日志未上传');
report=report.replace('代码/所核测试PASS；最终生产图/浏览增量待填','PASS；最终05b图与本人详情页均完整回复，无继续回复假状态');
report=report.replace('代码/所核测试PASS；最终图/浏览增量待填','PASS；本人有方案/无方案modal与PM完整授权反馈链图证一致');
report=report.replace('代码/所核测试PASS；最终首事项图待填','PASS；最终API/卡片断言及本人总览均为第三Case 1事项/继续当前事项');
report=report.replace('PM最终receipt/图/运行身份待末段绑定；非本人执行','PM最终receipt 7检查PASS、16图均本人实看、运行身份与本人只读浏览同a643；非本人执行E2E');
report=report.replace('| 待最终生产增量 |','| PASS；执行者与图证核验者分列 |');
report=report.replace('最终源/图待绑定后收口','最终源/图已由本报告与hash矩阵绑定');
report=report.replace('本轮代码/所核检查PASS，最终产品增量待填','本轮工程复核PASS；未测/用户门禁继续保留');
const begin=report.indexOf('## 原DW01–18及冻结交互影响映射');
const end=report.indexOf('## 四原则与IN01–IN07',begin);
report=report.slice(0,begin)+`## 原DW01–18及冻结交互影响映射

逐项结论只覆盖本候选影响；“原权威未改”不代表本轮重跑旧产品全集。

| 冻结基准 | 候选影响与核验 | 结论／实际边界 |
| --- | --- | --- |
| DW01 导航与等价入口 | 本人冻结/产品首页、Decision Case总览与详情往返；PM全部项目图 | PASS所核导航；原关系/管理入口无删除diff |
| DW02 G/S常驻、四页签、准确本轮原记录 | 本人稳定详情1440/1024/390与本轮概览DOM；源自保存记录且不把行动当达标 | PASS所核呈现；未重跑所有四页签业务写入 |
| DW03 列表/树及真实有向关系 | 本人冻结列表/树骨架及候选侧栏、PM星图/卡片；关系读写权威无diff | 原语义未改；本轮未重做多前驱关系写入全集 |
| DW04 浏览范围与协作事项分离 | CaseBoard原选择/范围回调无更改；CF03仅透传关联入口，原owner选择仍由原链处理 | 无发现回归；所有手选范围组合未独立重跑 |
| DW05 真实关联与准确来源 | CF04 owner/native/schema负例；PM Plan交回保留准确来源的40项受影响测试及最终原反馈图 | PASS受影响来源链；未重验所有资料权限排列 |
| DW06 全部项目及往返 | PM同名项目/关联原项目链、最终11图；本人入口/详情往返与零写 | PASS受影响链；独立/共享/归档服务原权威保留 |
| DW07 原项目归档准入与保护 | ProjectNavigation/Board仅AX名；CF07两同名项目只归档目标、原准入服务无diff | PASS所核；不引入stop/结束Case/任务启动 |
| DW08 首页明确请求 | 本人首页实际显示原承担人/轮次/请求时间，CF04原工具只保存明确请求；首页派生算法无diff | PASS所核；不把缺choice/feedback泛化成待办 |
| DW09 准确请求回应 | 本人只开关modal不写；PM Plan→choice→授权→反馈→原轮次/看板历史 | PASS受影响正向；无首页额外完成操作 |
| DW10 共用轻输入/可选整理 | CF05本地错误零POST；手填可继续；Home/Preparation入口实际浏览 | PASS受影响；未调用真实模型验证推荐质量 |
| DW11 三分支及不按标题合并 | CF06单位、原保留名称/背景/来源；实际第三Case创建后API与卡片1事项 | PASS受影响；全部历史三分支实Host组合未另重跑 |
| DW12 待带入片段保护/明确发送 | 本人详情有准确创建原文与来源、未自动追加/发送；PM Plan交接保持取舍草稿 | PASS所核；原片段权威未改 |
| DW13 草稿/导航/冲突与重复 | Task断连草稿→显式重连首发；CF03理由/下一步往返；卸载迟到导航原RED→GREEN | PASS受影响；所有原生重开/版本冲突组合未再独立穷举 |
| DW14 部分成功及原operation | CasePreparation本地确定拒绝/UNKNOWN边界原ID保留；首事项未完先通知、成功再通知 | PASS受影响；无新增跨Store原子承诺/写入自动重放 |
| DW15 目标结果与证据 | G/S/目标结果算法及源记录无diff；本人本轮概览明确行动与目标结果分别记录 | 无发现回归；未独立重验全部目标结果算法 |
| DW16 异常/旧快照/迟到/不重放 | CF01/02、FR01、body-stall与旧read-error原RED→GREEN；Case listStale/refreshSeq | PASS受影响；只读恢复不stop/open/messages，撤权原权限边界保留 |
| DW17 响应式/焦点/安全文字 | 本人冻结5图+产品8状态，1440/1024/390，modal390全控件可达、Esc归记录取舍；PM dark/字段聚焦/同名AX | PASS所核；1024原侧栏底部项目区较紧但本候选无CSS变化，未视为新增阻塞；全部旧XSS/树键盘排列未重跑 |
| DW18 原身份/历史/工程与模型采用分离 | 全19产品/测试diff、官方边界、本人71测试、3因果探针、PM真实Host合成SDK E2E、四原则 | PASS工程复核范围；不覆盖Mac自然现场、真实模型质量或用户设备采用；T10待用户新图确认 |

`+report.slice(end);
const visual=report.indexOf('## 最终产品视觉/只读浏览增量');
report=report.slice(0,visual)+`## 最终产品视觉／只读浏览增量

本人先通过独立HTTP实际操作冻结Demo首页／总览／详情／取舍，亲看5张1440/390截图及DOM/CSS骨架；随后亲看旧e72 16图，发现0事项/过渡态。原e72图与FAIL保留在PM的 intermediate-e72-product／production-e72-e2e.log。b88选择器错误（h3带◇）仅导致测试等待超时，原日志/图保留为 production-b88-selector.log／intermediate-b88-selector；a643只更正region定位器，不改产品。以上旧图不用于本候选用户确认。

最终PM正式clean构建的dist由Host同源直接服务，本人独立新Chromium context实际打开 http://127.0.0.1:43966 ，读取 /api/health 后只浏览现有数据。运行身份：commit a643bf00e79cba01933cbaa49a1616ecb675cf12，tree d9ab4d03512adf10a46b7bcb83dc4f8345a63e35，builtAt 2026-11-28T12:58:52.498Z，dirty=false，codeRoot为本候选树，instanceId 61e609cf-6867-40a9-920e-dd14996176bc。本人所捕获8状态记录在 final-browser/receipt.json，writes=[]、pageErrors=[]；没有模型/业务写操作。所有状态pageWidth与1440/1024/390视口宽度相等，390modal矩形358×721位于视口内，Esc后焦点回“记录取舍”。浏览后已通知PM，可正常关闭其所持精确进程，未杀用户服务。

| 冻结／预期 | 本人亲自浏览与截图 | PM最终16图及收据独立实看 | 结论 |
| --- | --- | --- | --- |
| 首页、准确待回应、继续入口 | final-browser/01-home-1440 | final-product/01-home-light-1440、02-preparation、12-field-validation | 骨架与原来源保留，局部校验明确聚焦；未误触发新写入 |
| 总览星图/卡片、创建即刷新 | final-browser/02-overview-1440读取3卡均1事项，第三有继续当前事项 | final-product/03-map、04-cards；永久E2E同时断言API第一事项1/卡片1/继续 | e72缺口关闭，非只截图标题 |
| G/S、四页签、稳定本轮概览及完整会话 | final-browser/03-detail-1440、06-detail-390、07-detail-1024 | final-product/05-detail、05b-heartbeat-recovered、08-dark、09-1024、10-390 | 稳定原记录完整显示、FR01终态读回；页面无横向溢出 |
| 取舍modal正常/空方案、明确Plan或关联入口 | final-browser/04-choice-1440、05-choice-390、08-empty-choice-1440 | final-product/06-unlinked、07-linked | 不把G/S当方案；原理由/下一步输入保留；390控件/页脚可达，Esc归焦 |
| 全部项目同名消歧与原反馈 | 本人看入口与准确关联只读资料 | final-product/11-all-projects、15-feedback-history，CF03完整Plan→取舍→授权→反馈→原历史receipt | 同一原项目/记录；反馈“未知”与实际观察分开；无Host代授权 |
| 任务首帧缺失、合法重连不丢输入 | 未触发业务写入；只实看原始最终图/receipt与测试 | final-product/13-task-disconnected、14-task-reconnected-draft | disconnected仍禁发保留草稿；显式重连后合法snapshot恢复再真实SDK首发 |

PM最终 e2e-receipt.json 为7检查PASS（CF05、CF06、CF02、CF03、CF01+CF04、FR01、CF07），synthetic Provider请求7，pageErrors=[]；consoleErrors8条404为隔离草稿尚不存在读回，未掩盖失败。本人不声称重跑此完整E2E；本人独立0写浏览与全部16图核验为交叉证据。全部最终图片、本人图片、冻结图与收据hash在 final-hash-matrix.json。截图构成没有重新设计布局；原冻结流程仍可达，CF03只加必要局部空态入口，CF05聚焦具体已有字段，CF07仅补AX上下文。

当前HEAD仍a643，19个产品/测试与冻结/依赖/规格输入再次逐hash匹配；30输入中仅tasks.md在PM归档时追加2行，明确原RED保留、引用本报告、T10仍未勾选，差异存tasks-evidence-increment.diff。运行时dirty=false来自构建与同源health。最终收口时PM正在加入implementation/tasks状态、报告/图证未提交文件；这不冒称当前工作树clean，也不影响已固定产品字节。若后续证据-only提交需另核产品与测试hash仍等于本矩阵。本报告只授予工程复核PASS，T10用户新图确认未发生，不创建PR、不授权合并。
`;
await fs.writeFile(path.join(out,'final-review.md'),report);
const artifactPaths=['final-review.md','input-e72df020.json','input-b88af4aa.json','input-a643bf00.json','final-b88-target-tests.log','target-tests.log','session-boundary.log','typecheck.log','late-read-error.log','late-read-error-green-worktree.log','late-read-error.test.ts','business/review-e72.md','business/incremental-green-worktree.md','business/final-b88-binding.json','business/late-plan-navigation-probe.json','business/late-plan-navigation-probe-green-worktree.json','business/first-issue-refresh-probe.json','business/first-issue-refresh-probe-green-worktree.json','final-browser/receipt.json','tasks-evidence-increment.diff'];
const artifacts=[];for(const relative of artifactPaths){const bytes=await fs.readFile(path.join(out,relative));artifacts.push({path:relative,bytes:bytes.length,sha256:hash(bytes)});}
for(const relative of ['.local/pm-review/final-product/e2e-receipt.json','.local/pm-review/final-product/runtime-identity.json','.local/pm-review/production-e2e.log']){try{const bytes=await fs.readFile(path.join(root,relative));artifacts.push({path:relative,bytes:bytes.length,sha256:hash(bytes),executedBy:'PM',reviewed:true});}catch{}}
const delta=input.files.filter(f=>b88.files.find(b=>b.path===f.path)?.sha256!==f.sha256);
const matrix={at:new Date().toISOString(),reviewer:'/root/trial_runtime_audit',head,productSourceEquivalentTo:'b88af4aa6dfd7f998bfb3e5e119b87820b287d99',b88ToA643ChangedInputs:delta,base:input.base,currentGitStatus:execFileSync('git',['status','--short'],{encoding:'utf8'}),allProductTestInputsMatchCandidate:current.filter(f=>f.path.startsWith('src/')||f.path.startsWith('tests/')).every(f=>f.matchesCandidate),candidate30InputMatches:current.filter(f=>f.matchesCandidate).length,documentOnlyIncrement:'tasks-evidence-increment.diff',inputs:current,artifacts,images:imageRows,runtime:own.runtime.runtime};
await fs.writeFile(path.join(out,'final-hash-matrix.json'),JSON.stringify(matrix,null,2));
const summary={at:matrix.at,result:'PASS_WITH_EXPLICIT_SCOPE',candidate:head,productSourceEquivalentTo:matrix.productSourceEquivalentTo,reviewerIsNonAuthor:true,blockingFindingsRemaining:0,priorFindings:{count:3,originalRedRetained:true,unchangedCauseProbeGreen:true,permanentRegressionPassed:true},personallyRun:{finalTargetTests:{tests:71,pass:71,fail:0,skip:0,cancelled:0,sourceCommit:matrix.productSourceEquivalentTo},agentSessionsBoundary:'PASS',typecheck:'PASS',frozenHttpBrowser:{states:5,personallyViewed:true},productionReadOnlyBrowser:{states:own.states.length,writes:own.writes,pageErrors:own.pageErrors,viewports:[1440,1024,390],runtime:own.runtime.runtime},productionImagesPersonallyViewed:16},pmExecutedReadOnlyReviewed:{productionE2E:{checks:pm.checks,result:pm.result,providerRequests:pm.providerRequests,pageErrors:pm.pageErrors},affectedRoleTests:40,coreTests:54,realHostHeartbeatProbeSeconds:50,cleanProductionBuild:'PASS'},matrices:{followup:'CF01-CF07,FR01-FR02,T01-T10',frozen:'DW01-DW18',principles:'4 principles,IN01-IN07'},notClaimed:['Full 524-file suite rerun','Mac original natural root cause or device acceptance','Paid/real model quality','Official registry archive redownload in this round'],remainingGate:{T10:'User confirmation of new actual product screenshots is pending; no PR permission',PRHeadCI:'not yet',authorizedMergeAndMainCI:'not yet'},artifacts:['final-review.md','final-hash-matrix.json']};
await fs.writeFile(path.join(out,'final-summary.json'),JSON.stringify(summary,null,2));
console.log(JSON.stringify({result:summary.result,head,inputCount:current.length,images:imageRows.length,sourceDrift:current.filter(f=>!f.matchesCandidate),b88Delta:delta.map(f=>f.path),reportSha256:artifacts[0].sha256},null,2));
