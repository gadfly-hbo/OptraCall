# Issue154 非作者最终候选复核：e72原始发现

身份：本复核者只参与原试用问题诊断，未参与Issue154候选产品实现、测试或规格创作；本轮仅只读候选，新增诊断脚本与证据仅保存在本目录。子复核者`final_business_matrix`亦未参与候选创作。主线74030911、候选e72df020f1040e68c3b16f12df1df6177dfc4a16，输入哈希见input-e72df020.json。

本轮亲自执行4份相关单测共67/67通过、check:agent-sessions通过、typecheck通过；这不覆盖以下新增因果探针检出的缺口。未重跑作者524文件全集、build、付费Provider或Mac。读取了PM原GET正文挂起RED及最终补丁，原RED保留。

## 必须处理的实际发现（均已立即通知根PM）

1. **P2 CF03，旧事项卸载后迟到的草稿保存仍触发导航。** `CaseIssuePanel.tsx:391/404`（以及同组handoff按钮）在await choiceDraft.flush后直接触发旧闭包导航，缺mounted检查。实际组件bundle/hook探针：草稿PUT挂起→卸载→释放PUT，旧onCreate仍一次调用并携旧Case/issue。证据business/late-plan-navigation-probe.json/.mjs。仅组件级受控迟到回调，未宣称浏览器发生串案或已经创建错任务。
2. **P2 CF01/PM追加，过期GET超时错误覆盖较新完成状态。** `BusinessRoleConversation.tsx:157–162`捕获期限错误时没有先核ticket/生命周期；成功分支有序号检查。实际组件探针：初始SSE触发GET-A正文挂起，用户发送新消息、GET-B返回completed全文，10s后旧A超时仍显示读取失败/原请求保留，虽然新请求已完成。证据late-read-error.test.ts/log；明确没有改写完成内容或业务终态，只是旧错误污染新UI。独立断言应拒绝这种告警，实际RED已保存。
3. **P2 CF06，总览刷新早于首事项确认，卡片缓存0事项。** `CasePreparation.tsx:313`created先onCaseChanged，之后才await finishFirstIssue，成功后不再通知。实际CasePreparation+CaseBoard/DailyCaseCard组件探针：通知读0→首事项完成→准备页明确首事项建立，但通知仍1、卡片仍0。证据business/first-issue-refresh-probe.json/.mjs。本人实际查看PM正式e72生产图final-product/03、04，第三Case卡片也显示0件/当前没有事项；原PM E2E只断言新Case标题出现，没有据此证明首事项正确显示。Mac及最终Host具体API状态仍由PM核查，不能从图单独假称API已1。

## 本人实际查看的视觉输入与边界

- 自己启动只读HTTP服务渲染冻结Demo，实际操作首页、总览、详情、取舍；截图frozen/home-1440、overview-1440、detail-1440、choice-1440、choice-390均已逐张view_image查看，DOM/CSS计算骨架在frozen/structure.json。未复制虚构数据到生产。
- 已逐张查看PM正式生产e72图final-product的01–15及05b；runtime-identity与receipt核到commit e72、dirty=false、当前codeRoot；该证据由PM执行，我只读复核，未冒称本人重跑真实Host/SDK E2E。
- 首页轻输入及四区、G/S与四页签、事项侧栏/单列、同页取舍弹窗、全局项目结构与原冻结层级一致；真实空态与数据不同如实显示。CF03局部无方案说明/Plan入口保持原表单，并没有G/S自动物化。
- 05-case-detail是“正在读取本轮记录/轮次待核”的过渡图，不能据此宣称稳定本轮概览全内容已视觉验收；建议PM最终重拍稳定状态。03/04第三卡0事项已作为上述实际发现处理。
- 1024图左侧底部拥挤是已有CSS、此候选未改CSS；不扩大本轮为全页设计调整。当前新候选用户截图确认尚无，T10/PR门禁仍未满足。

## 四原则与共享接入初核

Host只做观察、输入、准确权限/参数错误、列表失效；不替Agent生成方案/判断，不改原connected发送门禁。声明工具仍走原官方Pi工具和CaseStore/CAS权威，项目归档只增可访问名称、不变API ID闭包。包声明/锁文件对main无差异，官方归档完整性未在本独立轮重新下载比对，边界脚本只证明其覆盖范围。共享watchStrategyDiscussion新增opts可选，原StrategyDiscussionPanel无opts调用保持兼容；BusinessRoleConversation各owner隔离与取消历史合同仍须在最终候选增量复核。67项通过不抵消上述3个实际RED。

当前结论：**e72不通过完整CF01/CF03/CF06验收**。根PM已进入二审接修，不能安排第三次退回；本报告不授权PR或用户截图确认。后续修复与新的PASS必须分版本保存，不改写本原始结果。
