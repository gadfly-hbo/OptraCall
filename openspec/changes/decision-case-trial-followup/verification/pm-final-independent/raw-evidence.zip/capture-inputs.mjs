import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
const root=process.cwd(),out=path.join(root,'.local/independent-final-review'),base='74030911ade7a9e06ad1a0213d1fcb93ecbba6dd';
const head=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),changed=execFileSync('git',['diff','--name-only',base,'--','src','tests'],{encoding:'utf8'}).trim().split('\n');
const names=[...new Set([...changed,'AGENTS.md','docs/engineering-workflow.md','docs/agent-session-integration.md','openspec/changes/decision-case-trial-followup/spec.md','openspec/changes/decision-case-trial-followup/tasks.md','openspec/changes/decision-case-trial-followup/verification/second-review.md','openspec/changes/decision-case-daily-workspace/spec.md','openspec/changes/decision-case-daily-workspace/demo.html','package.json','package-lock.json','node_modules/@earendil-works/pi-coding-agent/package.json'])];const files=[];for(const name of names){const b=await fs.readFile(path.join(root,name));files.push({path:name,bytes:b.length,sha256:createHash('sha256').update(b).digest('hex')});}
await fs.writeFile(path.join(out,'input-'+head.slice(0,8)+'.json'),JSON.stringify({at:new Date().toISOString(),sourceRoot:root,head,base,status:execFileSync('git',['status','--short'],{encoding:'utf8'}),files},null,2));console.log(head+' '+files.length+' inputs');
