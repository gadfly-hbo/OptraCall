import test from 'node:test';
import assert from 'node:assert/strict';
import { build } from 'esbuild';
import { runInNewContext } from 'node:vm';
import { observeTask, type TaskObservationState } from '/workspace/OptraCall-issue154-second-review/src/host/ui/runtime-client.ts';
import { watchStrategyDiscussion, StrategyDiscussionRequestError } from '/workspace/OptraCall-issue154-second-review/src/host/ui/strategy-discussion-client.ts';
import { caseDeclarationsTool, explainCaseDeclarationError } from '/workspace/OptraCall-issue154-second-review/src/agent/strategy-discussion.ts';
import { CaseStore } from '/workspace/OptraCall-issue154-second-review/src/host/case-store.ts';
import { createCaseIssueService } from '/workspace/OptraCall-issue154-second-review/src/host/case-issues.ts';
import { emptyPreparePayload } from '/workspace/OptraCall-issue154-second-review/src/host/ui/case-preparation-model.ts';
import { diagnoseCaseDecisionRequestError } from '/workspace/OptraCall-issue154-second-review/src/host/strategy-discussion-host.ts';
import { createDecisionBoardStore } from '/workspace/OptraCall-issue154-second-review/extensions/business-plugins/decision-board/storage/store.ts';
import type { ClientProject } from '/workspace/OptraCall-issue154-second-review/src/host/ui/project-types.ts';
import { randomUUID } from 'node:crypto';
import { mkdtempSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';

type Element = { type: string | ((props: any) => any); props: Record<string, any> };
const descendants = (node: any): Element[] => !node || typeof node !== 'object' ? [] : Array.isArray(node) ? node.flatMap(descendants) : [node, ...descendants(node.props?.children)];
const textOf = (node: any): string => node == null || node === false ? '' : typeof node === 'string' || typeof node === 'number' ? String(node) : Array.isArray(node) ? node.map(textOf).join('') : textOf(node.props?.children);

let roleBundle: string | undefined;
async function mountBusinessRole(fetcher: typeof fetch, initialOwner: Record<string, unknown>) {
  roleBundle ??= (await build({
    entryPoints: ['src/host/ui/BusinessRoleConversation.tsx'],
    bundle: true, write: false, platform: 'browser', format: 'iife', loader: { '.css': 'empty' }, globalName: 'RoleUiTest',
    plugins: [{
      name: 'role-test-hooks',
      setup(plugin) {
        plugin.onResolve({ filter: /^react(?:\/jsx-runtime)?$/ }, args => ({ path: args.path, namespace: 'role-hooks' }));
        plugin.onLoad({ filter: /.*/, namespace: 'role-hooks' }, args => ({
          contents: args.path.endsWith('jsx-runtime')
            ? 'export const jsx=(type,props)=>({type,props});export const jsxs=jsx;export const Fragment="fragment";'
            : 'export const useState=v=>globalThis.__roleHooks.state(v);export const useRef=v=>globalThis.__roleHooks.ref(v);export const useEffect=(f,d)=>globalThis.__roleHooks.effect(f,d);export const useLayoutEffect=(f,d)=>globalThis.__roleHooks.effect(f,d);export const useCallback=(f,d)=>globalThis.__roleHooks.memo(()=>f,d);export const useMemo=(f,d)=>globalThis.__roleHooks.memo(f,d);export const useId=()=>globalThis.__roleHooks.id();export const Fragment="fragment";export const memo=c=>c;',
        }));
      },
    }],
  })).outputFiles[0].text;
  const instances = new Map<string, { values: any[]; deps: any[][]; cleanups: (() => void)[]; memos: { v: any; d: any[] }[] }>();
  const effects: (() => void)[] = [];
  let activeInst = { values: [] as any[], deps: [] as any[][], cleanups: [] as (() => void)[], memos: [] as { v: any; d: any[] }[] };
  let cursor = 0;
  let currentOwner = initialOwner;
  const hooks = {
    state(initial: any) { const inst = activeInst, i = cursor++; if (!(i in inst.values)) inst.values[i] = typeof initial === 'function' ? initial() : initial; return [inst.values[i], (v: any) => { inst.values[i] = typeof v === 'function' ? v(inst.values[i]) : v; }]; },
    ref(initial: any) { const inst = activeInst, i = cursor++; return inst.values[i] ??= { current: initial }; },
    memo(fn: () => any, next: any[]) { const inst = activeInst, i = cursor++; if (!inst.memos[i] || !next || next.some((v, n) => v !== inst.memos[i].d[n])) inst.memos[i] = { v: fn(), d: next ?? [] }; return inst.memos[i].v; },
    id() { return `role-${cursor++}`; },
    effect(fn: () => any, next: any[]) { const inst = activeInst, i = cursor++; if (!inst.deps[i] || next.some((v, n) => v !== inst.deps[i][n])) { inst.deps[i] = next; effects.push(() => { inst.cleanups[i]?.(); inst.cleanups[i] = fn(); }); } },
  };
  const sStore = new Map<string, string>(), lStore = new Map<string, string>();
  const storageApi = (m: Map<string, string>) => ({ getItem: (k: string) => m.get(k) ?? null, setItem: (k: string, v: string) => m.set(k, v), removeItem: (k: string) => m.delete(k) });
  const sandbox: Record<string, any> = {
    __roleHooks: hooks, fetch: fetcher, structuredClone, crypto,
    Response, Request, Headers, URL, URLSearchParams, TextDecoder, TextEncoder, setTimeout, clearTimeout,
    AbortController, AbortSignal, DOMException, ReadableStream,
    sessionStorage: storageApi(sStore), localStorage: storageApi(lStore),
    window: { addEventListener() {}, removeEventListener() {} },
  };
  runInNewContext(roleBundle, sandbox);
  const { BusinessRoleConversation } = sandbox.RoleUiTest;
  const seenKeys = new Set<string>();
  const expand = (node: any, path = 'root'): any => {
    if (!node || typeof node !== 'object') return node;
    if (Array.isArray(node)) return node.map((child, idx) => expand(child, `${path}.${idx}`));
    if (typeof node.type === 'function') {
      const instKey = `${path}:${node.type.name || 'fn'}:${node.props?.key ?? ''}`;
      seenKeys.add(instKey);
      let inst = instances.get(instKey);
      if (!inst) { inst = { values: [], deps: [], cleanups: [], memos: [] }; instances.set(instKey, inst); }
      const prevInst = activeInst, prevCursor = cursor;
      activeInst = inst; cursor = 0;
      const rendered = node.type(node.props);
      activeInst = prevInst; cursor = prevCursor;
      return expand(rendered, instKey);
    }
    if (node.props?.children !== undefined) return { ...node, props: { ...node.props, children: expand(node.props.children, path) } };
    return node;
  };
  let tree: Element;
  const render = () => {
    seenKeys.clear();
    tree = expand({ type: BusinessRoleConversation, props: { owner: currentOwner } });
    for (const [k, inst] of [...instances.entries()]) {
      if (!seenKeys.has(k)) { for (const fn of inst.cleanups) fn?.(); instances.delete(k); }
    }
    while (effects.length) effects.shift()!();
    return tree;
  };
  const settle = async (rounds = 8) => { for (let i = 0; i < rounds; i++) { await new Promise(r => setImmediate(r)); render(); } };
  render(); await settle();
  return {
    setOwner(next: Record<string, unknown>) { currentOwner = next; render(); },
    render, settle,
    nodes: () => descendants(tree),
    text: () => textOf(tree),
    close() { for (const inst of instances.values()) for (const fn of inst.cleanups) fn?.(); },
  };
}


test('Review: a superseded GET deadline must not overwrite a newer completed role read', async t=>{
 t.mock.timers.enable({apis:['setTimeout']});
 let getCount=0, sent='',oldAborted=false;
 const fetcher:typeof fetch=async(input,init)=>{
  const url=new URL(String(input),'http://localhost');
  if(url.pathname==='/api/configurations')return Response.json({configurations:[{id:'cfg',revision:1,name:'Synthetic',model:'synthetic',hasApiKey:true}]});
  const action=url.searchParams.get('action');
  if(action==='events')return new Response(new ReadableStream({start(c){c.enqueue(new TextEncoder().encode('data: '+JSON.stringify({type:'snapshot',snapshot:{sessionId:'s',status:'idle',messages:[],tools:[]}})+'\n\n'));init?.signal?.addEventListener('abort',()=>c.close(),{once:true});}}));
  if(init?.method==='POST'){sent=JSON.parse(String(init.body)).requestId;return Response.json({requestId:sent},{status:202});}
  getCount++;
  if(getCount===2)return new Response(new ReadableStream({start(c){c.enqueue(new TextEncoder().encode('{"discussion":'));init?.signal?.addEventListener('abort',()=>{oldAborted=true;c.error(new DOMException('Aborted','AbortError'));},{once:true});}}));
  return Response.json({discussion:{id:'d',revision:1,configurationId:'cfg',configurationRevision:1,...(sent?{lastRun:{id:sent,status:'completed'}}:{})},busy:false,snapshot:{sessionId:'s',status:'idle',messages:sent?[{role:'assistant',content:'newer completed reply'}]:[],tools:[]},...(sent?{requestReceipt:{requestId:sent,originalUserText:'newer message',nativeEntryId:'entry',sessionId:'s'}}:{})});
 };
 const ui=await mountBusinessRole(fetcher,{role:'project',projectId:'review-late-error'});
 try{
  assert.equal(getCount,2,'initial SSE snapshot must start the old stalled GET');
  ui.nodes().find(n=>n.type==='textarea')!.props.onChange({target:{value:'newer message'}});await ui.settle();
  ui.nodes().find(n=>n.type==='form')!.props.onSubmit({preventDefault(){}});await ui.settle(12);
  assert.match(ui.text(),/newer completed reply/);assert.doesNotMatch(ui.text(),/正在回复/);
  t.mock.timers.tick(10000);await ui.settle(12);
  assert.equal(oldAborted,true);console.log(JSON.stringify({getCount,oldAborted,ui:ui.text()}));
  assert.doesNotMatch(ui.text(),/读取原对话状态超时/,'superseded read error must not replace newer completion with stale timeout notice');
 }finally{ui.close();}
});
